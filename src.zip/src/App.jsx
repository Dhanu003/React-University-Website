import React from 'react';
import Navbar from './components/Navbar/Navbar'; 
import Hero from './components/hero/hero'; 
import Courses from './components/courses/courses';
import Title from './components/title/title';
import About from './components/about/about';
import Campus from './components/campus/campus';
import Reviews from './components/reviews/reviews';
import Contact from './components/contact/contact';
import Footer from './components/footer/footer';
import LoginRegisterPopup from './components/LoginRegisterPopup/LoginRegisterPopup';

const App = () => {
  return (
    <div>
      <Navbar />
      <Hero />
      <div className='container'>
        <Title subtitle='OUR COURSES' title='What We Bring to You' />
        <Courses/>
        <Title subtitle='ABOUT US' title='Who We Are & What We Do' />
        <About />
        <Title subtitle='GALLERY' title='Our Vibrant Campus Life' />
        <Campus/>
        <Title subtitle='Reviews & Ratings' title='What People Say' />
        <Reviews/>
        <Title subtitle='Contact Us' title='Get in Touch' />
        <Contact/>
        <Footer/>
        <LoginRegisterPopup/>
       
        
       

        
      </div>
    
    </div>
  );
};

export default App;
