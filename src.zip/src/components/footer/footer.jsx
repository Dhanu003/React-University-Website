import React from 'react';
import './footer.css';
import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope, FaLinkedin, FaGithub, FaInstagram } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">

        <div className="footer-section">
          <h3>Address</h3>
          <p><FaMapMarkerAlt className="icon" /> 123 Tech Park, Pune, Maharashtra, India - 411001</p>
        </div>

        <div className="footer-section">
          <h3>Contact Us</h3>
          <p><FaEnvelope className="icon" /> contact@yourdomain.com</p>
          <p><FaPhoneAlt className="icon" /> +91 98765 43210</p>
        </div>

        <div className="footer-section">
          <h3>Follow Us</h3>
          <div className="social-icons">
            <a href="https://www.linkedin.com/in/dhanashree-babar-72956022b" target="_blank" rel="noopener noreferrer">
                <FaLinkedin />
            </a>
            <a href="https://github.com/your-github-username" target="_blank" rel="noopener noreferrer">
                <FaGithub />
            </a>
            <a href="https://www.instagram.com/your-instagram-username" target="_blank" rel="noopener noreferrer">
                <FaInstagram />
            </a>
          </div>

        </div>

      </div>

      <div className="footer-bottom">
        &copy; {new Date().getFullYear()} Dhanashree Babar | All rights reserved
      </div>
    </footer>
  );
};

export default Footer;
