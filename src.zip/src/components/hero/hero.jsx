import React from 'react'
import './hero.css'
import dark_arrow from '../../assets/dark-arrow.png'

const hero = () => {
  return (
    <div className='hero container'>
      <div className="hero-text">
        <h1>Building a Brighter World Through Education</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
          Alias deserunt commodi totam repudiandae sequi tenetur voluptas dolorum id eveniet ut.</p>
          <button className='btn'>Explore more <img src= {dark_arrow} alt="" /></button>
      </div>
    </div>
  )
}

export default hero
