import React, { useState, useEffect } from 'react';
import './LoginRegisterPopup.css';
import { FaEnvelope, FaLock, FaUser } from 'react-icons/fa';

const LoginRegisterPopup = () => {
  const [showModal, setShowModal] = useState(false);
  const [isLogin, setIsLogin] = useState(true);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');


  useEffect(() => {
    setShowModal(true);
  }, []);

  const toggleForm = () => setIsLogin(!isLogin);
  const handleClose = () => setShowModal(false);

  const handleSubmit = (e) => {
  e.preventDefault();
  // collect form data here and handle login/register logic

  
  if (!email || !password || (!isLogin && !name)) {
    alert('Please fill all required fields.');
    return;
  }

  if (isLogin) {
    // Handle login logic
    console.log('Logging in with:', { email, password });
  } else {
    // Handle registration logic
    console.log('Registering with:', { name, email, password });
  }

  // Reset form fields after submit
  setName('');
  setEmail('');
  setPassword('');
  setShowModal(false); // Optional: close popup after successful submit
};

  return showModal ? (
    <div className="popup-overlay">
      <div className="popup-glass">
        <button className="close-btn" onClick={handleClose}>×</button>
        <h2>{isLogin ? 'Login to Continue' : 'Create an Account'}</h2>
      <form onSubmit={handleSubmit}>

          {!isLogin && (
            <div className="input-group">
              <FaUser />
             <input type="text" value={name} onChange={(e) => setName(e.target.value)} />

            </div>
          )}
          <div className="input-group">
            <FaEnvelope />
            <input type="email" value = {email}  onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
          </div>
          <div className="input-group">
            <FaLock />
            <input type="password" value = {password}  onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
          </div>
          <button type="submit" className="submit-btn">
            {isLogin ? 'Login' : 'Register'}
          </button>
        </form>
        <p onClick={toggleForm} className="toggle-text">
          {isLogin ? "Don't have an account? Register" : "Already have an account? Login"}
        </p>
      </div>
    </div>
  ) : null;
};

export default LoginRegisterPopup;
