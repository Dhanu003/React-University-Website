import React from 'react'
import './courses.css'
import courses_1 from '../../assets/program-1.jpg'
import courses_2 from '../../assets/program-2.jpg'
import courses_3 from '../../assets/program-3.jpg'

import courses_icon_1 from  '../../assets/program-icon-1.png'
import courses_icon_2 from  '../../assets/program-icon-2.png'
import courses_icon_3 from  '../../assets/program-icon-3.png'
const courses = () => {
  return (
    <div className='courses'>
        <div className='course'>
            <img src={courses_1} alt="" />
            <div className="caption">
                <img src={courses_icon_1} alt="" />
                <p>Graduation Degree</p>
            </div>
        </div>
         <div className='course'>
            <img src={courses_2} alt="" />
            <div className="caption">
                <img src={courses_icon_2} alt="" />
                <p>Master Degree</p>
            </div>
        </div>
         <div className='course'>
            <img src={courses_3} alt="" />
            <div className="caption">
                <img src={courses_icon_3} alt="" />
                <p>Post Graduation Degree</p>
            </div>
        </div>     
    </div>
  )
}

export default courses
