import React from 'react';
import './about.css';
import university_promo from '../../assets/university_promo.mp4';

const About = () => {
  return (
    <div className='about-section'>
      <div className="about-left">
        <video src={university_promo} autoPlay loop muted />
      </div>
      <div className="about-right">
        <h2>Discover Our University</h2>
        <p>
        
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusamus doloribus
          quam ullam sapiente impedit delectus, vero eos suscipit, perferendis harum recusandae, 
          nulla corporis quas? Expedita possimus.
        </p>
        <button className="learn-more">Learn More</button>
      </div>
    </div>
  );
};

export default About;
